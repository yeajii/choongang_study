package com.oracle.oBootUpa01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBootUpa01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
