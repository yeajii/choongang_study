package sam06;

public interface Vehicle {
	// 추상메소드
	void ride();

}
