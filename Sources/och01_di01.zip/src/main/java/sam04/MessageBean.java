package sam04;

public interface MessageBean {
	void sayHello();

}
