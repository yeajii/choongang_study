package sam07;

public interface MessageBean {
	void sayHello();

}
