package sam07;

public interface Outputter {
	void output(String msg);

}
