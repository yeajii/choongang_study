package sam03;

public interface MessageBean {
	void sayHello();

}
