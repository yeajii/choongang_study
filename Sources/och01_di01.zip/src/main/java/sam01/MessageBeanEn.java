package sam01;

public class MessageBeanEn {
	void sayHello(String name) {
		System.out.println(name + " Hello");
	}

}
