package sam01;

public class MessageBeanKo {
	void sayHello(String name) {
		System.out.println(name + " 안녕");
	}

}
