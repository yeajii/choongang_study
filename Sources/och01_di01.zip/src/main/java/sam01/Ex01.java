package sam01;

public class Ex01 {

	public static void main(String[] args) {
		// 전통적인 방식
		// MessageBeanEn mb = new MessageBeanEn();
		MessageBeanKo mb = new MessageBeanKo();
		mb.sayHello("spring");
	}

}
