package sam02;

public class Ex02 {

	public static void main(String[] args) {
		// MessageBean mb = new MessageBeanKo();
		
		MessageBean mb = new MessageBeanEn();
		
		mb.sayHello("spring");
	}

}
