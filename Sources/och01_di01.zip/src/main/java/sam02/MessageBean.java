package sam02;

public interface MessageBean {
	void sayHello(String name);

}
