package sam02;

public class MessageBeanKo implements MessageBean {

	public void sayHello(String name) {
		System.out.println(name + "! 안녕하세요");

	}

}
