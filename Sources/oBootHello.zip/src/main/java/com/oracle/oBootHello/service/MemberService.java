package com.oracle.oBootHello.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oracle.oBootHello.domain.Member1;
import com.oracle.oBootHello.repository.MemberRepository;
import com.oracle.oBootHello.repository.MemoryMemberRepository;

// 인스턴스 만들 수 있게 됨 
@Service  
public class MemberService {
	// 전통적인 방식
	// MemberRepository memberRepository = new MemoryMemberRepository();
	
	// DI 방식
	private final MemberRepository memberRepository;
	
	// 생성자
	@Autowired  // 모든 bean들을 자동으로 연결 시킴
	public MemberService(MemberRepository memberRepository) {
		this.memberRepository = memberRepository;
	}
	
	
	// 회원가입
	public Long memberSave(Member1 member1) {
		System.out.println("MemberService memberSave Start");
		
		memberRepository.save(member1);
		
		return member1.getId();
	}
	
	
	// 회원조회 
	public List<Member1> allMembers(){
		System.out.println("MemberService allMembers Start");
		
		List<Member1> memList = null;
		memList = memberRepository.findAll();
		System.out.println("memList.size()" + memList.size());
		
		return memList;
	}
	
	
	
	
	
	

}
