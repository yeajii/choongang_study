package com.oracle.oBootUpaApi01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBootUpaApi01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
