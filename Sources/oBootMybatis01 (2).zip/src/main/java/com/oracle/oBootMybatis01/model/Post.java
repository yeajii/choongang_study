package com.oracle.oBootMybatis01.model;

public class Post {
	
	private int post_no;
}
