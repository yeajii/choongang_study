package DI06;

public class StudentInfo {
	private Student student;
	
	// 생성자
	public StudentInfo() {
	}

	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	
	

}
